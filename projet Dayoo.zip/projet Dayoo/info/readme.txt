Nom        : Roger
Prenom     : Dayna
Code       :32690
vacation   :Median A
section    :sciences informatique